<?php

class Role {
    private string $_personnage;
    private array $_listeInterpretations;

    function __construct(string $personnage) {
        $this->_personnage = $personnage;
        $this->_listeInterpretations = [];
    }
    function __toString() {
        return $this->_personnage;
    }

    public function getPersonnage() {
        return $this->_personnage;
    }
    public function getListeInterpretations() {
        return $this->_listeInterpretations;
    } 
    public function ajouterInterpretation(Interpretation $interpretation) {
        $this->_listeInterpretations []= $interpretation;
    }

    public function listeInterpretationsToDisplay() {
        $toDisplay = "<p>Acteurs ayant inteprêté le rôle de <i>".$this."</i> :</p><ul>";
        foreach ($this->_listeInterpretations as $interpretation) {
            $toDisplay .= "<li><b>".$interpretation->getActeur()."</b> dans le film « ".$interpretation->getFilm()." »</li>";
        }
        $toDisplay .= "</ul>";
        return $toDisplay;
    }
}